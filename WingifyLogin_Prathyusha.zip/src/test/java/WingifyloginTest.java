import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.testng.Assert;
import org.testng.annotations.*;

import java.util.*;


import org.testng.annotations.BeforeMethod;
        import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

public class WingifyloginTest {


    WebDriver driver;

    @BeforeMethod
    public void beforemethod() {

        EdgeOptions edgeOptions = new EdgeOptions();
        edgeOptions.addArguments("--remote-allow-origins=*");
        WebDriverManager.edgedriver().setup();
        driver = new EdgeDriver(edgeOptions);
        driver.manage().window().maximize();
        driver.navigate().to("https://sakshingp.github.io/assignment/login.html");
        driver.manage().window().maximize();
    }
    // Test 1: Functional Testing Scenarios for Login Page
    @Test
    public void comparingURls()
    {
        String actualUrl= driver.getCurrentUrl();
        System.out.println(actualUrl);
        String expectedURl="https://sakshingp.github.io/assignment/login.html";
        Assert.assertEquals(actualUrl,expectedURl);
    }
    @Test
    public void comparingTitles() {

        String actualTitle = driver.getTitle();
        System.out.println(actualTitle);
        String expectedTitle = "Demo App";
        Assert.assertEquals(actualTitle, expectedTitle, "titles didnt match");
    }
    @Test
    public void isLoginformDisplayed()
    {
        driver.findElement(By.xpath("//h4[@class='auth-header']")).isDisplayed();
    }
    @Test
    public void isUsernameDisplayed()
    {
        driver.findElement(By.xpath("//label[text()='Username']")).isDisplayed();
    }
    @Test
    public void isPasswordDisplayed()
    {
        driver.findElement(By.xpath("//label[text()='Password']")).isDisplayed();
    }
    @Test
    public void isLoginbuttonEnable()
    {
        driver.findElement(By.xpath("//button[@id='log-in']")).isEnabled();
    }
    @Test
    public void isRemembermeDisplayed()
    {
        driver.findElement(By.xpath("//label[@class='form-check-label']")).isDisplayed();
    }
    @Test
    public void isRemembermeClickable() {
        driver.findElement(By.xpath("//input[@type='checkbox']")).click();
        driver.findElement(By.xpath("//input[@type='checkbox']")).isSelected();

    }
    @Test
    public void isTwitterlogoDisplayed()
    {
        driver.findElement(By.xpath("//a[@style='display: inline-block; margin-bottom:4px;']")).isDisplayed();
    }
    @Test
    public void isFacebookLogoDisplayed()
    {
        driver.findElement(By.xpath("//img[@src='img/facebook.png']")).isDisplayed();
    }
    @Test
    public void isLinkedinLogoDisplayed()
    {
        driver.findElement(By.xpath("//img[@src='img/linkedin.png']")).isDisplayed();
    }
    @Test
    public void isUsernameTextboxDispalyed()
    {
        driver.findElement(By.xpath("//input[@placeholder='Enter your username']")).isDisplayed();
    }
    @Test
    public void ispasswordTextboxDisplayed()
    {
        driver.findElement(By.xpath("//input[@placeholder='Enter your password']")).isDisplayed();
    }


    // Login with valid username and eampty password

    @Test
    public void test2()
    {
        login(driver,"hi","");
        String name=driver.findElement(By.xpath("//div[text()='Password must be present']")).getText();
        System.out.println(name);
        String expectedMessage="Password must be present";
        Assert.assertEquals(name,expectedMessage,"didnt match");


    }
    // Login with empty username and valid password
    @Test
    public void test3()
    {
        login(driver,"","hi");
        String name=driver.findElement(By.xpath("//div[text()='Username must be present']")).getText();
        System.out.println(name);
        String expectdmsg="Username must be present";
        Assert.assertEquals(name,expectdmsg);

    }
    //Login with empty username and empty password
    @Test
    public void test4()
    {
        login(driver,"","");
        String both=driver.findElement(By.xpath("//div[text()='Both Username and Password must be present ']")).getText();
        System.out.println(both);
        String expected="Both Username and Password must be present";
        Assert.assertEquals(both,expected);

    }
    public static void login(WebDriver driver, String username, String password) {
        WebElement usernameButton = driver.findElement(By.xpath("//input[@id='username']"));
        WebElement passwordButton = driver.findElement(By.xpath("//input[@id='password']"));
        WebElement loginButton = driver.findElement(By.xpath("//button[@id='log-in']"));
        usernameButton.sendKeys(username);
        passwordButton.sendKeys(password);
        loginButton.click();
    }
    // Login with valid username and password
    @Test
    public void test1() throws InterruptedException {
        login(driver, "hii", "hello");
        String actualHomepage = driver.getTitle();
        System.out.println(actualHomepage);
        String expectedHomepageTitle = "Demo App";
        Assert.assertEquals(actualHomepage, expectedHomepageTitle);

Thread.sleep(4000);
        driver.findElement(By.xpath("//th[@onclick='sortTable(4)']")).click();
        Thread.sleep(4000);

        List<WebElement> list = driver.findElements(By.xpath("//td[@class='text-right bolder nowrap']"));
        List<String> amountlistActual = new ArrayList();
        for (int i = 0; i < list.size(); i++) {
            WebElement ele = (WebElement) list.toArray()[i];
            String valueText = ele.getText().replaceAll("[^0-9\\-+]", "");
            amountlistActual.add(valueText);
        }
        List<String> sortedValuesText = new ArrayList<>(amountlistActual);
        Collections.sort(sortedValuesText, new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {
                double value1 = Double.parseDouble(o1);
                double value2 = Double.parseDouble(o2);

                // Compare in descending order
                if (value1 < value2) {
                    return -1;
                } else if (value1 > value2) {
                    return 1;
                } else {
                    return 0;
                }
            }
        });

        Assert.assertTrue(amountlistActual.equals(sortedValuesText));
    }
    @AfterMethod
    public void aftermethod()
    {
        driver.close();
    }
}




